////
////  WishListView.swift
////  EventsUp
////
////  Created by Gagenapally,Roshni Damodar Reddy on 1/31/23.
////
//
//import SwiftUI
//
//struct WishListView: View {
//    
//    @EnvironmentObject var dataManager: DataManager
//    
//    var body: some View {
////        NavigationView {
////            List(dataManager.records, id: \.id) { record in
////                Text(record.EventName)
////            }
////            .navigationTitle("WishList")
////            .navigationBarItems(trailing: Button(action: {
////                //add
////            }, label: {
////                Image(systemName: "plus")
////            }))
////        }
//        
//    }
//}
//
//struct WishListView_Previews: PreviewProvider {
//    static var previews: some View {
//        WishListView()
//    }
//}
