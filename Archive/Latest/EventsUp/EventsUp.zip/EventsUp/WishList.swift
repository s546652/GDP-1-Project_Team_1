//
//  WishList.swift
//  EventsUp
//
//  Created by Gagenapally,Roshni Damodar Reddy on 1/31/23.
//

import Foundation
import SwiftUI

struct WishList {
   // var id: ObjectIdentifier
    
    
    var EventName : String?
    var EventDate : String?
    var user : String?
    var userId: String?
}
