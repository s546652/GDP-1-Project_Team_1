//
//  LoginController.swift
//  EventsUp
//
//  Created by Gundu,Naveen Kumar on 10/1/22.
//

import UIKit
import Firebase
import SwiftUI
class LoginController: UIViewController {
    var gobalUsername:String = ""
    @IBOutlet weak var wishlitsOutlet: UIBarButtonItem!
    
    @IBOutlet weak var emailOutlet: UITextField!
    
    @IBOutlet weak var passwordOutlet: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        print("test login")
        wishlitsOutlet.isEnabled = false
    }
    
    
    
    @IBAction func loginBTN(_ sender: Any) {
        Auth.auth().signIn(withEmail: emailOutlet.text!, password: passwordOutlet.text!){Result, error in
            if error != nil {
                print(error!.localizedDescription)
            }
            else {
                print("logged in")
                self.wishlitsOutlet.isEnabled = true
                self.gobalUsername = self.emailOutlet.text!
                self.performSegue(withIdentifier: "loginSegue", sender: self)
            }
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            let trans = segue.identifier
                if trans == "wishlistsegue" {
                    let des = segue.destination as! wishListControllerViewController
                    print("wishLsit")
                }
            else if trans == "loginSegue" {
                let des = segue.destination as! EventsDetailListViewController
                des.gUsername = self.gobalUsername
                print("^^^^^^^^^^^")
                print(des.gUsername)

            }
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
